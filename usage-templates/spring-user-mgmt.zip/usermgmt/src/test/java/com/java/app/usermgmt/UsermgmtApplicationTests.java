package com.java.app.usermgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
